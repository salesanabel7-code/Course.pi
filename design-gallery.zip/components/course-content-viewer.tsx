"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { toast } from "@/hooks/use-toast"

const PlayIcon = () => (
  <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <polygon points="5,3 19,12 5,21" />
  </svg>
)

const LockIcon = () => (
  <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
    <circle cx="12" cy="16" r="1" />
    <path d="M7 11V7a5 5 0 0 1 10 0v4" />
  </svg>
)

const CheckCircleIcon = () => (
  <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
    <polyline points="22,4 12,14.01 9,11.01" />
  </svg>
)

const DownloadIcon = () => (
  <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
    <polyline points="7,10 12,15 17,10" />
    <line x1="12" y1="15" x2="12" y2="3" />
  </svg>
)

interface CourseContentViewerProps {
  courseId: string
  hasAccess: boolean
  onAccessRequired: () => void
}

export function CourseContentViewer({ courseId, hasAccess, onAccessRequired }: CourseContentViewerProps) {
  const [courseContent, setCourseContent] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [currentLesson, setCurrentLesson] = useState<any>(null)
  const [completedLessons, setCompletedLessons] = useState<string[]>([])

  useEffect(() => {
    fetchCourseContent()
  }, [courseId, hasAccess])

  const fetchCourseContent = async () => {
    try {
      setLoading(true)
      const response = await fetch(`/api/course-content/${courseId}`, {
        headers: {
          "x-user-id": "user_123", // Mock user ID
        },
      })

      const data = await response.json()

      if (data.success && data.hasAccess) {
        setCourseContent(data.content)
        // Set first lesson as current
        if (data.content.modules.length > 0 && data.content.modules[0].lessons.length > 0) {
          setCurrentLesson(data.content.modules[0].lessons[0])
        }
      } else {
        toast({
          title: "Access Required",
          description: data.message || "You need to purchase this course to access the content",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load course content",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const markLessonComplete = (lessonId: string) => {
    if (!completedLessons.includes(lessonId)) {
      setCompletedLessons([...completedLessons, lessonId])
      toast({
        title: "Lesson Completed",
        description: "Great job! Keep up the momentum.",
      })
    }
  }

  const calculateProgress = () => {
    if (!courseContent) return 0
    const totalLessons = courseContent.modules.reduce((acc: number, module: any) => acc + module.lessons.length, 0)
    return totalLessons > 0 ? (completedLessons.length / totalLessons) * 100 : 0
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="mt-2 text-muted-foreground">Loading course content...</p>
        </div>
      </div>
    )
  }

  if (!hasAccess) {
    return (
      <div className="text-center p-8">
        <LockIcon className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
        <h3 className="text-lg font-semibold mb-2">Course Access Required</h3>
        <p className="text-muted-foreground mb-4">
          Purchase this course to unlock all lessons, resources, and assignments.
        </p>
        <Button onClick={onAccessRequired}>Get Access</Button>
      </div>
    )
  }

  if (!courseContent) {
    return (
      <div className="text-center p-8">
        <p className="text-muted-foreground">Failed to load course content</p>
        <Button variant="outline" onClick={fetchCourseContent} className="mt-2 bg-transparent">
          Try Again
        </Button>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Progress Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Your Progress</span>
            <Badge variant="outline">{Math.round(calculateProgress())}% Complete</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Progress value={calculateProgress()} className="mb-2" />
          <p className="text-sm text-muted-foreground">
            {completedLessons.length} of{" "}
            {courseContent.modules.reduce((acc: number, module: any) => acc + module.lessons.length, 0)} lessons
            completed
          </p>
        </CardContent>
      </Card>

      <div className="grid gap-6 lg:grid-cols-[1fr_300px]">
        {/* Main Content Area */}
        <div className="space-y-6">
          {currentLesson && (
            <Card>
              <CardHeader>
                <CardTitle>{currentLesson.title}</CardTitle>
                <div className="flex items-center gap-2">
                  <Badge variant="outline">{currentLesson.duration}</Badge>
                  {completedLessons.includes(currentLesson.id) && (
                    <Badge variant="default" className="bg-green-600">
                      <CheckCircleIcon className="h-3 w-3 mr-1" />
                      Completed
                    </Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Video Player Placeholder */}
                <div className="aspect-video bg-muted rounded-lg flex items-center justify-center">
                  <div className="text-center">
                    <PlayIcon className="h-12 w-12 mx-auto text-muted-foreground mb-2" />
                    <p className="text-muted-foreground">Video: {currentLesson.title}</p>
                    <p className="text-sm text-muted-foreground">{currentLesson.duration}</p>
                  </div>
                </div>

                {/* Lesson Controls */}
                <div className="flex items-center justify-between">
                  <Button variant="outline">Previous Lesson</Button>
                  <Button onClick={() => markLessonComplete(currentLesson.id)}>
                    {completedLessons.includes(currentLesson.id) ? "Completed" : "Mark Complete"}
                  </Button>
                  <Button variant="outline">Next Lesson</Button>
                </div>

                {/* Lesson Resources */}
                {currentLesson.resources && currentLesson.resources.length > 0 && (
                  <div>
                    <h4 className="font-semibold mb-2">Lesson Resources</h4>
                    <div className="space-y-2">
                      {currentLesson.resources.map((resource: any, index: number) => (
                        <div key={index} className="flex items-center justify-between p-2 border rounded">
                          <span className="text-sm">{resource.name}</span>
                          <Button size="sm" variant="outline">
                            <DownloadIcon className="mr-1" />
                            Download
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Transcript */}
                {currentLesson.transcript && (
                  <div>
                    <h4 className="font-semibold mb-2">Transcript</h4>
                    <div className="p-4 bg-muted rounded-lg">
                      <p className="text-sm">{currentLesson.transcript}</p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Assignments */}
          {courseContent.assignments && courseContent.assignments.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Assignments</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {courseContent.assignments.map((assignment: any) => (
                    <div key={assignment.id} className="p-4 border rounded-lg">
                      <h4 className="font-semibold">{assignment.title}</h4>
                      <p className="text-sm text-muted-foreground mt-1">{assignment.description}</p>
                      <div className="flex items-center justify-between mt-3">
                        <Badge variant="outline">Format: {assignment.submissionFormat}</Badge>
                        <Button size="sm">Submit Assignment</Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Sidebar - Course Modules */}
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Course Content</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="space-y-1">
                {courseContent.modules.map((module: any, moduleIndex: number) => (
                  <div key={module.id}>
                    <div className="px-4 py-2 bg-muted font-medium text-sm">
                      Module {moduleIndex + 1}: {module.title}
                    </div>
                    {module.lessons.map((lesson: any, lessonIndex: number) => (
                      <button
                        key={lesson.id}
                        onClick={() => setCurrentLesson(lesson)}
                        className={`w-full text-left px-4 py-2 text-sm hover:bg-muted/50 flex items-center justify-between ${
                          currentLesson?.id === lesson.id ? "bg-primary/10 border-r-2 border-primary" : ""
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          {completedLessons.includes(lesson.id) ? (
                            <CheckCircleIcon className="h-4 w-4 text-green-600" />
                          ) : (
                            <PlayIcon className="h-4 w-4 text-muted-foreground" />
                          )}
                          <span>
                            {moduleIndex + 1}.{lessonIndex + 1} {lesson.title}
                          </span>
                        </div>
                        <span className="text-xs text-muted-foreground">{lesson.duration}</span>
                      </button>
                    ))}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Certificate */}
          {courseContent.certificates?.available && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Certificate</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-3">{courseContent.certificates.requirements}</p>
                <Button
                  className="w-full"
                  disabled={calculateProgress() < 100}
                  variant={calculateProgress() === 100 ? "default" : "outline"}
                >
                  {calculateProgress() === 100 ? "Download Certificate" : "Complete Course First"}
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
