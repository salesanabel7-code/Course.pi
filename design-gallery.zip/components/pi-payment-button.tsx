"use client"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { useRouter } from "next/navigation"

interface PiPaymentButtonProps {
  courseId: string
  courseTitle: string
  price: string
  onPaymentSuccess?: () => void
}

export function PiPaymentButton({ courseId, courseTitle, price, onPaymentSuccess }: PiPaymentButtonProps) {
  const router = useRouter()

  const handlePiPayment = () => {
    router.push(`/payment/${courseId}`)
  }

  return (
    <div className="flex items-center gap-3">
      <Badge variant="outline" className="text-orange-600 border-orange-600">
        <span className="mr-1">π</span>
        {price} Pi
      </Badge>
      <Button onClick={handlePiPayment} className="bg-orange-600 hover:bg-orange-700">
        <span className="mr-2">π</span>
        Buy with Pi
      </Button>
    </div>
  )
}
