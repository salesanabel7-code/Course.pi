"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { toast } from "@/hooks/use-toast"

const WalletIcon = () => (
  <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"
    />
  </svg>
)

const CopyIcon = () => (
  <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"
    />
  </svg>
)

interface PiWalletPaymentProps {
  amount: string
  courseId: string
  courseTitle: string
  recipientWallet?: string
  onPaymentInitiated?: (walletAddress: string) => void
}

export function PiWalletPayment({
  amount,
  courseId,
  courseTitle,
  recipientWallet = "GCXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
  onPaymentInitiated,
}: PiWalletPaymentProps) {
  const [senderWallet, setSenderWallet] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text)
      toast({
        title: "Copied!",
        description: "Wallet address copied to clipboard",
      })
    } catch (error) {
      toast({
        title: "Copy Failed",
        description: "Please copy the address manually",
        variant: "destructive",
      })
    }
  }

  const handleWalletPayment = async () => {
    if (!senderWallet.trim()) {
      toast({
        title: "Wallet Address Required",
        description: "Please enter your Pi wallet address",
        variant: "destructive",
      })
      return
    }

    if (senderWallet.length < 56) {
      toast({
        title: "Invalid Wallet Address",
        description: "Pi wallet addresses should be 56 characters long",
        variant: "destructive",
      })
      return
    }

    setIsProcessing(true)

    try {
      const paymentData = {
        method: "wallet",
        senderWallet: senderWallet.trim(),
        recipientWallet,
        amount: Number.parseFloat(amount),
        courseId,
        courseTitle,
        timestamp: new Date().toISOString(),
      }

      console.log("[v0] Initiating Pi wallet payment:", paymentData)

      // Mock wallet payment processing
      await new Promise((resolve) => setTimeout(resolve, 2000))

      onPaymentInitiated?.(senderWallet.trim())

      toast({
        title: "Payment Initiated!",
        description: `Please complete the π ${amount} transfer in your Pi wallet app`,
      })
    } catch (error) {
      toast({
        title: "Payment Failed",
        description: "Failed to initiate wallet payment. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader className="text-center">
        <CardTitle className="flex items-center justify-center gap-2">
          <WalletIcon />
          Direct Wallet Payment
        </CardTitle>
        <CardDescription>Transfer Pi directly from your wallet</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="recipient-wallet">Recipient Wallet Address</Label>
          <div className="flex items-center gap-2">
            <Input id="recipient-wallet" value={recipientWallet} readOnly className="font-mono text-xs bg-gray-50" />
            <Button
              variant="outline"
              size="sm"
              onClick={() => copyToClipboard(recipientWallet)}
              className="flex-shrink-0"
            >
              <CopyIcon />
            </Button>
          </div>
          <p className="text-xs text-gray-500">This is the course creator's Pi wallet address</p>
        </div>

        <div className="space-y-2">
          <Label htmlFor="sender-wallet">Your Wallet Address</Label>
          <Input
            id="sender-wallet"
            placeholder="Enter your Pi wallet address"
            value={senderWallet}
            onChange={(e) => setSenderWallet(e.target.value)}
            className="font-mono text-xs"
          />
          <p className="text-xs text-gray-500">Enter your Pi wallet address for transaction verification</p>
        </div>

        <div className="bg-orange-50 p-4 rounded-lg space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium">Payment Amount:</span>
            <Badge variant="outline" className="text-orange-600 border-orange-600 text-lg">
              π {amount}
            </Badge>
          </div>

          <div className="text-xs text-orange-800 space-y-2">
            <p>
              <strong>Payment Instructions:</strong>
            </p>
            <ol className="list-decimal list-inside space-y-1 ml-2">
              <li>Copy the recipient wallet address above</li>
              <li>Open your Pi Network wallet app</li>
              <li>Initiate a transfer of π {amount}</li>
              <li>Paste the recipient address</li>
              <li>Add memo: "Course: {courseId}"</li>
              <li>Complete the transaction</li>
            </ol>
          </div>
        </div>

        <Button
          onClick={handleWalletPayment}
          disabled={isProcessing || !senderWallet.trim()}
          className="w-full bg-orange-600 hover:bg-orange-700"
        >
          {isProcessing ? (
            <>
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
              Processing...
            </>
          ) : (
            <>
              <WalletIcon />
              <span className="ml-2">Confirm Payment Details</span>
            </>
          )}
        </Button>

        <div className="text-center">
          <p className="text-xs text-gray-500">
            After completing the wallet transfer, your payment will be verified and course access granted
          </p>
        </div>
      </CardContent>
    </Card>
  )
}
