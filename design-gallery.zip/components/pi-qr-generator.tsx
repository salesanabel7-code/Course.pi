"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"

interface PiQRGeneratorProps {
  amount: string
  courseId: string
  recipientWallet?: string
  memo?: string
}

export function PiQRGenerator({ amount, courseId, recipientWallet, memo }: PiQRGeneratorProps) {
  const [qrCodeUrl, setQrCodeUrl] = useState<string>("")

  useEffect(() => {
    generateQRCode()
  }, [amount, courseId, recipientWallet, memo])

  const generateQRCode = async () => {
    try {
      const piPaymentData = {
        amount: Number.parseFloat(amount),
        memo: memo || `Course purchase: ${courseId}`,
        recipient: recipientWallet || "GCXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
        metadata: {
          courseId,
          timestamp: Date.now(),
        },
      }

      // In real implementation, this would use Pi Network SDK to generate QR code
      // For now, we'll use a placeholder QR code service
      const qrData = encodeURIComponent(JSON.stringify(piPaymentData))
      const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${qrData}&bgcolor=fff&color=f97316`

      setQrCodeUrl(qrCodeUrl)
    } catch (error) {
      console.error("Failed to generate QR code:", error)
    }
  }

  return (
    <Card className="w-full max-w-sm mx-auto">
      <CardContent className="p-6 text-center">
        <div className="mb-4">
          <h3 className="font-semibold text-lg mb-2">Scan to Pay with Pi</h3>
          <p className="text-sm text-gray-600">Use your Pi Network app to scan this QR code</p>
        </div>

        <div className="bg-white p-4 rounded-lg border-2 border-dashed border-gray-300 mb-4">
          {qrCodeUrl ? (
            <img src={qrCodeUrl || "/placeholder.svg"} alt="Pi Payment QR Code" className="w-48 h-48 mx-auto" />
          ) : (
            <div className="w-48 h-48 mx-auto flex items-center justify-center bg-gray-100 rounded">
              <div className="text-center">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-orange-600 mx-auto mb-2"></div>
                <p className="text-sm text-gray-500">Generating QR Code...</p>
              </div>
            </div>
          )}
        </div>

        <div className="space-y-2 text-sm text-gray-600">
          <div className="flex justify-between">
            <span>Amount:</span>
            <span className="font-semibold text-orange-600">π {amount}</span>
          </div>
          <div className="flex justify-between">
            <span>Course ID:</span>
            <span className="font-mono text-xs">{courseId}</span>
          </div>
        </div>

        <div className="mt-4 p-3 bg-orange-50 rounded-lg">
          <p className="text-xs text-orange-800">
            <strong>Instructions:</strong>
            <br />
            1. Open your Pi Network app
            <br />
            2. Tap the QR scanner
            <br />
            3. Scan this code to initiate payment
            <br />
            4. Confirm the transaction in your app
          </p>
        </div>
      </CardContent>
    </Card>
  )
}
