"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

const DollarSignIcon = () => (
  <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1"
    />
  </svg>
)

const TrendingUpIcon = () => (
  <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
  </svg>
)

const ShoppingCartIcon = () => (
  <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M3 3h2l.4 2M7 13h10l4-8H5.4m0 0L7 13m0 0l-2.5 2.5M7 13l2.5 2.5"
    />
  </svg>
)

const ClockIcon = () => (
  <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
    />
  </svg>
)

interface CreatorEarnings {
  totalEarnings: string
  pendingPayments: string
  thisMonth: string
  coursesSold: number
  recentPayments: Array<{
    id: string
    courseTitle: string
    amount: string
    date: string
    status: string
  }>
}

export default function CreatorDashboard() {
  const [earnings, setEarnings] = useState<CreatorEarnings | null>(null)
  const [piWallet, setPiWallet] = useState("")
  const [isUpdatingWallet, setIsUpdatingWallet] = useState(false)

  useEffect(() => {
    fetchEarnings()
  }, [])

  const fetchEarnings = async () => {
    try {
      const response = await fetch("/api/creator-payments?creatorId=creator_123")
      const data = await response.json()
      if (data.success) {
        setEarnings(data.earnings)
      }
    } catch (error) {
      console.error("Failed to fetch earnings:", error)
    }
  }

  const updateWallet = async () => {
    setIsUpdatingWallet(true)
    // Mock wallet update
    await new Promise((resolve) => setTimeout(resolve, 1000))
    setIsUpdatingWallet(false)
  }

  if (!earnings) {
    return <div className="flex justify-center items-center min-h-screen">Loading...</div>
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Creator Dashboard</h1>
          <p className="text-gray-600">Track your course sales and Pi earnings</p>
        </div>

        {/* Earnings Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Earnings</CardTitle>
              <DollarSignIcon />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-600">π {earnings.totalEarnings}</div>
              <p className="text-xs text-muted-foreground">All-time Pi earnings</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">This Month</CardTitle>
              <TrendingUpIcon />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">π {earnings.thisMonth}</div>
              <p className="text-xs text-muted-foreground">January 2024</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Courses Sold</CardTitle>
              <ShoppingCartIcon />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{earnings.coursesSold}</div>
              <p className="text-xs text-muted-foreground">Total enrollments</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pending</CardTitle>
              <ClockIcon />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-yellow-600">π {earnings.pendingPayments}</div>
              <p className="text-xs text-muted-foreground">Awaiting approval</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Payment Settings */}
          <Card>
            <CardHeader>
              <CardTitle>Pi Wallet Settings</CardTitle>
              <CardDescription>Configure your Pi Network wallet for receiving payments</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="pi-wallet">Pi Wallet Address</Label>
                <Input
                  id="pi-wallet"
                  placeholder="Enter your Pi wallet address"
                  value={piWallet}
                  onChange={(e) => setPiWallet(e.target.value)}
                />
              </div>
              <Button onClick={updateWallet} disabled={isUpdatingWallet} className="w-full">
                {isUpdatingWallet ? "Updating..." : "Update Wallet Address"}
              </Button>
              <div className="bg-orange-50 p-3 rounded-lg">
                <p className="text-sm text-orange-800">
                  <strong>Revenue Share:</strong> You earn 85% of each sale, platform keeps 15% as service fee.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Recent Payments */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Payments</CardTitle>
              <CardDescription>Your latest Pi earnings from course sales</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {earnings.recentPayments.map((payment) => (
                  <div key={payment.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium text-sm">{payment.courseTitle}</p>
                      <p className="text-xs text-gray-500">{payment.date}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold text-orange-600">π {payment.amount}</p>
                      <Badge variant={payment.status === "processed" ? "default" : "secondary"} className="text-xs">
                        {payment.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
