"use client"

import { useState } from "react"
import { ArrowLeft, CheckCircle, XCircle, MessageSquare, User, Clock, DollarSign } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { MainNav } from "@/components/main-nav"
import { UserNav } from "@/components/user-nav"
import { Separator } from "@/components/ui/separator"
import { toast } from "@/hooks/use-toast"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

interface CourseReviewPageProps {
  params: {
    courseId: string
  }
}

export default function CourseReviewPage({ params }: CourseReviewPageProps) {
  const [feedback, setFeedback] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)

  const handleApproval = async (approved: boolean) => {
    setIsProcessing(true)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1500))

      toast({
        title: approved ? "Course Approved" : "Course Rejected",
        description: approved
          ? "The course has been approved and is now live on the platform."
          : "The course has been rejected. The instructor will be notified with your feedback.",
      })

      // In a real app, redirect to admin dashboard
    } catch (error) {
      toast({
        title: "Error",
        description: "There was an error processing the course review.",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  // Mock course data - in real app, this would be fetched based on courseId
  const course = {
    id: params.courseId,
    title: "Mobile App Design Principles",
    description:
      "Learn the fundamental principles of mobile app design, including user experience, interface design, and platform-specific guidelines. This comprehensive course covers everything from wireframing to high-fidelity prototypes.",
    instructor: {
      name: "Emma Wilson",
      email: "emma.wilson@example.com",
      avatar: "/diverse-group-four.png",
      joinDate: "March 2024",
      coursesPublished: 2,
      rating: 4.7,
    },
    category: "UI Design",
    level: "Intermediate",
    price: "18.5",
    duration: "4h 15m",
    submittedDate: "2024-01-15",
    modules: [
      {
        id: "1",
        title: "Introduction to Mobile Design",
        description: "Overview of mobile design principles and best practices",
        duration: "25 min",
      },
      {
        id: "2",
        title: "User Research for Mobile Apps",
        description: "Understanding your mobile users and their needs",
        duration: "35 min",
      },
      {
        id: "3",
        title: "Wireframing and Information Architecture",
        description: "Creating effective wireframes for mobile interfaces",
        duration: "45 min",
      },
      {
        id: "4",
        title: "Visual Design and UI Components",
        description: "Designing beautiful and functional mobile interfaces",
        duration: "50 min",
      },
      {
        id: "5",
        title: "Prototyping and Testing",
        description: "Creating interactive prototypes and conducting usability tests",
        duration: "40 min",
      },
    ],
    thumbnail: "/mobile-app-ui-design.png",
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background">
        <div className="container flex h-16 items-center px-4 sm:px-8">
          <MainNav />
          <div className="ml-auto flex items-center space-x-4">
            <UserNav />
          </div>
        </div>
      </header>

      <main className="flex-1">
        <div className="container px-4 py-6 sm:px-8 md:py-8 max-w-6xl">
          <div className="mb-6">
            <Link href="/admin" className="inline-flex items-center text-sm text-muted-foreground hover:text-primary">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Admin Dashboard
            </Link>
          </div>

          <div className="mb-8">
            <h1 className="text-3xl font-bold tracking-tight">Course Review</h1>
            <p className="text-muted-foreground">Review and approve or reject this course submission</p>
          </div>

          <div className="grid gap-8 lg:grid-cols-3">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-6">
              {/* Course Overview */}
              <Card>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-2xl">{course.title}</CardTitle>
                      <CardDescription className="mt-2">{course.description}</CardDescription>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-green-600">{course.price} π</div>
                      <div className="text-sm text-muted-foreground">{course.duration}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 mt-4">
                    <Badge variant="outline">{course.category}</Badge>
                    <Badge variant="outline">{course.level}</Badge>
                    <Badge variant="outline" className="text-orange-600 border-orange-600">
                      <Clock className="h-3 w-3 mr-1" />
                      Pending Review
                    </Badge>
                  </div>
                </CardHeader>
              </Card>

              {/* Course Modules */}
              <Card>
                <CardHeader>
                  <CardTitle>Course Content ({course.modules.length} modules)</CardTitle>
                  <CardDescription>Review the course structure and content</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {course.modules.map((module, index) => (
                    <div key={module.id} className="border rounded-lg p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <Badge variant="outline">Module {index + 1}</Badge>
                            <span className="text-sm text-muted-foreground">{module.duration}</span>
                          </div>
                          <h4 className="font-medium">{module.title}</h4>
                          <p className="text-sm text-muted-foreground mt-1">{module.description}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Review Actions */}
              <Card>
                <CardHeader>
                  <CardTitle>Review Decision</CardTitle>
                  <CardDescription>Provide feedback and approve or reject this course</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid gap-2">
                    <Label htmlFor="feedback">Feedback for Instructor (optional)</Label>
                    <Textarea
                      id="feedback"
                      placeholder="Provide constructive feedback about the course content, structure, or any improvements needed..."
                      rows={4}
                      value={feedback}
                      onChange={(e) => setFeedback(e.target.value)}
                    />
                  </div>
                  <div className="flex gap-4">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="destructive" disabled={isProcessing}>
                          <XCircle className="mr-2 h-4 w-4" />
                          Reject Course
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Reject Course</DialogTitle>
                          <DialogDescription>
                            Are you sure you want to reject this course? The instructor will be notified with your
                            feedback.
                          </DialogDescription>
                        </DialogHeader>
                        <DialogFooter>
                          <Button variant="outline">Cancel</Button>
                          <Button variant="destructive" onClick={() => handleApproval(false)}>
                            Reject Course
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>

                    <Dialog>
                      <DialogTrigger asChild>
                        <Button disabled={isProcessing}>
                          <CheckCircle className="mr-2 h-4 w-4" />
                          Approve Course
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Approve Course</DialogTitle>
                          <DialogDescription>
                            Are you sure you want to approve this course? It will be published immediately and available
                            for purchase.
                          </DialogDescription>
                        </DialogHeader>
                        <DialogFooter>
                          <Button variant="outline">Cancel</Button>
                          <Button onClick={() => handleApproval(true)}>Approve Course</Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Instructor Info */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <User className="h-5 w-5" />
                    Instructor Details
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center gap-3">
                    <Avatar className="h-12 w-12">
                      <AvatarImage src={course.instructor.avatar || "/placeholder.svg"} />
                      <AvatarFallback>{course.instructor.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <h4 className="font-medium">{course.instructor.name}</h4>
                      <p className="text-sm text-muted-foreground">{course.instructor.email}</p>
                    </div>
                  </div>
                  <Separator />
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Member since:</span>
                      <span>{course.instructor.joinDate}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Courses published:</span>
                      <span>{course.instructor.coursesPublished}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Average rating:</span>
                      <span className="flex items-center gap-1">⭐ {course.instructor.rating}</span>
                    </div>
                  </div>
                  <Button variant="outline" className="w-full bg-transparent">
                    <MessageSquare className="mr-2 h-4 w-4" />
                    Contact Instructor
                  </Button>
                </CardContent>
              </Card>

              {/* Submission Details */}
              <Card>
                <CardHeader>
                  <CardTitle>Submission Details</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Submitted:</span>
                    <span>Jan 15, 2024</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Status:</span>
                    <Badge variant="outline" className="text-orange-600 border-orange-600">
                      Pending Review
                    </Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Course ID:</span>
                    <span className="font-mono">{course.id}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Total modules:</span>
                    <span>{course.modules.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Estimated revenue:</span>
                    <span className="flex items-center gap-1">
                      <DollarSign className="h-3 w-3" />
                      {course.price} π per sale
                    </span>
                  </div>
                </CardContent>
              </Card>

              {/* Review Checklist */}
              <Card>
                <CardHeader>
                  <CardTitle>Review Checklist</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center gap-2 text-sm">
                    <input type="checkbox" id="content-quality" className="rounded" />
                    <label htmlFor="content-quality">Content quality is appropriate</label>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <input type="checkbox" id="course-structure" className="rounded" />
                    <label htmlFor="course-structure">Course structure is logical</label>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <input type="checkbox" id="pricing-fair" className="rounded" />
                    <label htmlFor="pricing-fair">Pricing is fair and competitive</label>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <input type="checkbox" id="guidelines-met" className="rounded" />
                    <label htmlFor="guidelines-met">Meets platform guidelines</label>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <input type="checkbox" id="no-violations" className="rounded" />
                    <label htmlFor="no-violations">No policy violations</label>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
