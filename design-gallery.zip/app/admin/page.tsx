"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { MainNav } from "@/components/main-nav"
import { UserNav } from "@/components/user-nav"
import { toast } from "@/hooks/use-toast"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"

const UsersIcon = () => (
  <svg className="h-4 w-4 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z"
    />
  </svg>
)

const BookOpenIcon = () => (
  <svg className="h-4 w-4 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.746 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"
    />
  </svg>
)

const DollarSignIcon = () => (
  <svg className="h-4 w-4 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1"
    />
  </svg>
)

const TrendingUpIcon = () => (
  <svg className="h-4 w-4 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
  </svg>
)

const EyeIcon = () => (
  <svg className="h-4 w-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
    />
  </svg>
)

const CheckCircleIcon = () => (
  <svg className="h-4 w-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
    />
  </svg>
)

const XCircleIcon = () => (
  <svg className="h-4 w-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z"
    />
  </svg>
)

const ClockIcon = () => (
  <svg className="h-3 w-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <circle cx="12" cy="12" r="10" />
    <polyline points="12,6 12,12 16,14" />
  </svg>
)

export default function AdminDashboard() {
  const [pendingPayments, setPendingPayments] = useState(mockPendingPayments)
  const [rejectionNotes, setRejectionNotes] = useState("")
  const [platformFeeRate, setPlatformFeeRate] = useState("15")
  const [minPaymentAmount, setMinPaymentAmount] = useState("1.0")
  const [maxPaymentAmount, setMaxPaymentAmount] = useState("1000.0")
  const [autoApprovalEnabled, setAutoApprovalEnabled] = useState(false)

  const handlePaymentApproval = async (paymentId: string, approved: boolean, notes?: string) => {
    try {
      const response = await fetch(`/api/admin/payments/${paymentId}/approve`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          approved,
          adminId: "admin_123",
          notes,
        }),
      })

      const result = await response.json()

      if (result.success) {
        // Update local state
        setPendingPayments(pendingPayments.filter((payment) => payment.id !== paymentId))

        toast({
          title: approved ? "Payment Approved" : "Payment Rejected",
          description: approved
            ? "Course access has been granted and creator payment processed"
            : "Payment has been rejected and user notified",
        })
      } else {
        throw new Error(result.error)
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to process payment approval",
        variant: "destructive",
      })
    }
  }

  const updatePaymentSettings = async () => {
    try {
      const response = await fetch("/api/admin/payment-settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          platformFeeRate: Number.parseFloat(platformFeeRate) / 100,
          minPaymentAmount: Number.parseFloat(minPaymentAmount),
          maxPaymentAmount: Number.parseFloat(maxPaymentAmount),
          autoApprovalEnabled,
        }),
      })

      const result = await response.json()
      if (result.success) {
        toast({
          title: "Settings Updated",
          description: "Payment settings have been successfully updated",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update payment settings",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background">
        <div className="container flex h-16 items-center px-4 sm:px-8">
          <MainNav />
          <div className="ml-auto flex items-center space-x-4">
            <UserNav />
          </div>
        </div>
      </header>

      <main className="flex-1">
        <div className="container px-4 py-6 sm:px-8 md:py-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold tracking-tight">Admin Dashboard</h1>
            <p className="text-muted-foreground">Manage your course marketplace platform</p>
          </div>

          {/* Stats Overview */}
          <div className="mb-8 grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Users</CardTitle>
                <UsersIcon />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">2,847</div>
                <p className="text-xs text-muted-foreground">+12% from last month</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Active Courses</CardTitle>
                <BookOpenIcon />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">156</div>
                <p className="text-xs text-muted-foreground">+8 new this week</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Pi Revenue</CardTitle>
                <DollarSignIcon />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">12,847 π</div>
                <p className="text-xs text-muted-foreground">+23% from last month</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Enrollments</CardTitle>
                <TrendingUpIcon />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">8,924</div>
                <p className="text-xs text-muted-foreground">+18% from last month</p>
              </CardContent>
            </Card>
          </div>

          <Tabs defaultValue="courses" className="space-y-4">
            <TabsList>
              <TabsTrigger value="courses">Course Management</TabsTrigger>
              <TabsTrigger value="users">User Management</TabsTrigger>
              <TabsTrigger value="pending">Pending Approvals</TabsTrigger>
              <TabsTrigger value="payments">
                Pi Payments
                {pendingPayments.length > 0 && (
                  <Badge variant="destructive" className="ml-2">
                    {pendingPayments.length}
                  </Badge>
                )}
              </TabsTrigger>
              <TabsTrigger value="payment-settings">Payment Settings</TabsTrigger>
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
            </TabsList>

            <TabsContent value="courses" className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold">Course Management</h2>
                <Button>Add New Course</Button>
              </div>
              <div className="grid gap-4">
                {mockCourses.map((course) => (
                  <Card key={course.id}>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className="h-16 w-16 rounded-lg bg-muted"></div>
                          <div>
                            <h3 className="font-semibold">{course.title}</h3>
                            <p className="text-sm text-muted-foreground">by {course.instructor}</p>
                            <div className="flex items-center gap-2 mt-1">
                              <Badge variant={course.status === "active" ? "default" : "secondary"}>
                                {course.status}
                              </Badge>
                              <span className="text-sm text-muted-foreground">{course.enrollments} enrolled</span>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="font-semibold">{course.price} π</span>
                          <Button variant="outline" size="sm">
                            <EyeIcon />
                            View
                          </Button>
                          <Button variant="outline" size="sm">
                            Edit
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="users" className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold">User Management</h2>
                <Button variant="outline">Export Users</Button>
              </div>
              <div className="grid gap-4">
                {mockUsers.map((user) => (
                  <Card key={user.id}>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <Avatar>
                            <AvatarImage src={user.avatar || "/placeholder.svg"} />
                            <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <div>
                            <h3 className="font-semibold">{user.name}</h3>
                            <p className="text-sm text-muted-foreground">{user.email}</p>
                            <div className="flex items-center gap-2 mt-1">
                              <Badge
                                variant={
                                  user.role === "admin"
                                    ? "destructive"
                                    : user.role === "instructor"
                                      ? "default"
                                      : "secondary"
                                }
                              >
                                {user.role}
                              </Badge>
                              <span className="text-sm text-muted-foreground">Joined {user.joinDate}</span>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button variant="outline" size="sm">
                            View Profile
                          </Button>
                          <Button variant="outline" size="sm">
                            Edit
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="pending" className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold">Pending Course Approvals</h2>
                <Badge variant="secondary">{mockPendingCourses.length} pending</Badge>
              </div>
              <div className="grid gap-4">
                {mockPendingCourses.map((course) => (
                  <Card key={course.id}>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className="h-16 w-16 rounded-lg bg-muted"></div>
                          <div>
                            <h3 className="font-semibold">{course.title}</h3>
                            <p className="text-sm text-muted-foreground">by {course.instructor}</p>
                            <div className="flex items-center gap-2 mt-1">
                              <Badge variant="outline">
                                <ClockIcon />
                                Pending Review
                              </Badge>
                              <span className="text-sm text-muted-foreground">Submitted {course.submittedDate}</span>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="font-semibold">{course.price} π</span>
                          <Button variant="outline" size="sm">
                            <EyeIcon />
                            Review
                          </Button>
                          <Button variant="default" size="sm">
                            <CheckCircleIcon />
                            Approve
                          </Button>
                          <Button variant="destructive" size="sm">
                            <XCircleIcon />
                            Reject
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="payments" className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold">Pi Network Payments</h2>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="text-orange-600 border-orange-600">
                    <span className="mr-1">π</span>
                    {pendingPayments.length} Pending Approval
                  </Badge>
                  <Button variant="outline">Export Transactions</Button>
                </div>
              </div>

              {/* Pending Payments Section */}
              {pendingPayments.length > 0 && (
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <h3 className="text-lg font-semibold">Pending Payment Approvals</h3>
                    <Badge variant="destructive">{pendingPayments.length}</Badge>
                  </div>
                  <div className="grid gap-4">
                    {pendingPayments.map((payment) => (
                      <Card key={payment.id} className="border-orange-200 bg-orange-50/50">
                        <CardContent className="p-6">
                          <div className="flex items-center justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-4">
                                <div className="h-12 w-12 rounded-lg bg-orange-100 flex items-center justify-center">
                                  <span className="text-orange-600 font-bold text-lg">π</span>
                                </div>
                                <div>
                                  <h4 className="font-semibold">{payment.course}</h4>
                                  <p className="text-sm text-muted-foreground">
                                    Student: {payment.buyer} • Instructor: {payment.instructor}
                                  </p>
                                  <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                                    <span>Amount: {payment.amount} π</span>
                                    <span>Method: {payment.method || "Wallet"}</span>
                                    <span>Submitted: {payment.date}</span>
                                    <span>Pi Wallet: {payment.piWallet}</span>
                                  </div>
                                  <div className="mt-2 p-2 bg-white rounded border text-xs">
                                    <span className="text-green-600">
                                      Creator will receive: π {(Number.parseFloat(payment.amount) * 0.85).toFixed(2)}
                                    </span>
                                    <span className="text-gray-500 ml-4">
                                      Platform fee: π {(Number.parseFloat(payment.amount) * 0.15).toFixed(2)}
                                    </span>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <Button
                                variant="default"
                                size="sm"
                                onClick={() => handlePaymentApproval(payment.id, true)}
                              >
                                <CheckCircleIcon />
                                Approve & Pay Creator
                              </Button>
                              <Dialog>
                                <DialogTrigger asChild>
                                  <Button variant="destructive" size="sm">
                                    <XCircleIcon />
                                    Reject
                                  </Button>
                                </DialogTrigger>
                                <DialogContent>
                                  <DialogHeader>
                                    <DialogTitle>Reject Payment</DialogTitle>
                                    <DialogDescription>
                                      Please provide a reason for rejecting this payment. The student will be notified.
                                    </DialogDescription>
                                  </DialogHeader>
                                  <div className="grid gap-4 py-4">
                                    <div className="grid gap-2">
                                      <Label htmlFor="rejection-notes">Rejection Reason</Label>
                                      <Textarea
                                        id="rejection-notes"
                                        placeholder="Enter reason for rejection..."
                                        value={rejectionNotes}
                                        onChange={(e) => setRejectionNotes(e.target.value)}
                                      />
                                    </div>
                                  </div>
                                  <DialogFooter>
                                    <Button
                                      variant="destructive"
                                      onClick={() => {
                                        handlePaymentApproval(payment.id, false, rejectionNotes)
                                        setRejectionNotes("")
                                      }}
                                    >
                                      Reject Payment
                                    </Button>
                                  </DialogFooter>
                                </DialogContent>
                              </Dialog>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              )}

              {/* Completed Transactions */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Recent Transactions</h3>
                <div className="grid gap-4">
                  {mockTransactions.map((transaction) => (
                    <Card key={transaction.id}>
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                          <div>
                            <h3 className="font-semibold">{transaction.course}</h3>
                            <p className="text-sm text-muted-foreground">
                              {transaction.buyer} → {transaction.instructor}
                            </p>
                            <p className="text-xs text-muted-foreground">{transaction.date}</p>
                          </div>
                          <div className="text-right">
                            <div className="font-semibold text-green-600">+{transaction.amount} π</div>
                            <Badge variant={transaction.status === "completed" ? "default" : "secondary"}>
                              {transaction.status}
                            </Badge>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="payment-settings" className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold">Payment Settings</h2>
                <Button onClick={updatePaymentSettings}>Save Settings</Button>
              </div>

              <div className="grid gap-6 md:grid-cols-2">
                <Card>
                  <CardHeader>
                    <CardTitle>Revenue Share Settings</CardTitle>
                    <CardDescription>Configure how payments are split between creators and platform</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="platform-fee">Platform Fee Percentage</Label>
                      <div className="flex items-center gap-2">
                        <Input
                          id="platform-fee"
                          type="number"
                          min="0"
                          max="50"
                          value={platformFeeRate}
                          onChange={(e) => setPlatformFeeRate(e.target.value)}
                          className="w-20"
                        />
                        <span className="text-sm text-muted-foreground">%</span>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Creators receive {100 - Number.parseInt(platformFeeRate)}% of each sale
                      </p>
                    </div>

                    <div className="bg-orange-50 p-3 rounded-lg">
                      <h4 className="font-medium text-sm mb-2">Revenue Split Preview</h4>
                      <div className="text-sm space-y-1">
                        <div className="flex justify-between">
                          <span>Course Price: π 20.0</span>
                        </div>
                        <div className="flex justify-between text-green-600">
                          <span>Creator Receives:</span>
                          <span>π {((20 * (100 - Number.parseInt(platformFeeRate))) / 100).toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between text-gray-600">
                          <span>Platform Fee:</span>
                          <span>π {((20 * Number.parseInt(platformFeeRate)) / 100).toFixed(2)}</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Payment Limits</CardTitle>
                    <CardDescription>Set minimum and maximum payment amounts</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="min-payment">Minimum Payment Amount (π)</Label>
                      <Input
                        id="min-payment"
                        type="number"
                        min="0.1"
                        step="0.1"
                        value={minPaymentAmount}
                        onChange={(e) => setMinPaymentAmount(e.target.value)}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="max-payment">Maximum Payment Amount (π)</Label>
                      <Input
                        id="max-payment"
                        type="number"
                        min="1"
                        step="1"
                        value={maxPaymentAmount}
                        onChange={(e) => setMaxPaymentAmount(e.target.value)}
                      />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Payment Methods</CardTitle>
                    <CardDescription>Configure available Pi Network payment options</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">Pi Username Payment</p>
                          <p className="text-sm text-muted-foreground">Allow payments via Pi Network username</p>
                        </div>
                        <Badge variant="default">Enabled</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">QR Code Payment</p>
                          <p className="text-sm text-muted-foreground">Generate QR codes for Pi payments</p>
                        </div>
                        <Badge variant="default">Enabled</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">Wallet Address Payment</p>
                          <p className="text-sm text-muted-foreground">Direct wallet-to-wallet transfers</p>
                        </div>
                        <Badge variant="default">Enabled</Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Approval Settings</CardTitle>
                    <CardDescription>Configure payment approval workflow</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Manual Approval Required</p>
                        <p className="text-sm text-muted-foreground">All payments require admin approval</p>
                      </div>
                      <Badge variant="secondary">Active</Badge>
                    </div>

                    <div className="bg-blue-50 p-3 rounded-lg">
                      <p className="text-sm text-blue-800">
                        <strong>Note:</strong> Auto-approval will be available in future updates. Currently, all Pi
                        payments require manual admin approval for security.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="analytics" className="space-y-4">
              <h2 className="text-2xl font-bold">Platform Analytics</h2>
              <div className="grid gap-4 md:grid-cols-2">
                <Card>
                  <CardHeader>
                    <CardTitle>Course Performance</CardTitle>
                    <CardDescription>Top performing courses this month</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {mockCourses.slice(0, 3).map((course, index) => (
                        <div key={course.id} className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-medium">#{index + 1}</span>
                            <span className="text-sm">{course.title}</span>
                          </div>
                          <span className="text-sm font-medium">{course.enrollments} enrolled</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader>
                    <CardTitle>Revenue Breakdown</CardTitle>
                    <CardDescription>Pi earnings by category</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex justify-between">
                        <span>UI/UX Design</span>
                        <span className="text-sm font-medium">4,250 π</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Web Development</span>
                        <span className="text-sm font-medium">3,890 π</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Graphic Design</span>
                        <span className="text-sm font-medium">2,847 π</span>
                      </div>
                      <div className="flex justify-between">
                        <span>3D & Animation</span>
                        <span className="text-sm font-medium">1,860 π</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}

// Mock data
const mockCourses = [
  {
    id: "1",
    title: "Advanced UI/UX Design Masterclass",
    instructor: "Sarah Johnson",
    status: "active",
    enrollments: 234,
    price: "15.5",
  },
  {
    id: "2",
    title: "React Development Bootcamp",
    instructor: "Mike Chen",
    status: "active",
    enrollments: 189,
    price: "22.0",
  },
  {
    id: "3",
    title: "3D Animation Fundamentals",
    instructor: "Alex Rivera",
    status: "draft",
    enrollments: 67,
    price: "18.5",
  },
]

const mockUsers = [
  {
    id: "1",
    name: "John Doe",
    email: "john@example.com",
    role: "student",
    joinDate: "Jan 2024",
    avatar: "/diverse-person.png",
  },
  {
    id: "2",
    name: "Sarah Johnson",
    email: "sarah@example.com",
    role: "instructor",
    joinDate: "Dec 2023",
    avatar: "/diverse-group.png",
  },
  {
    id: "3",
    name: "Admin User",
    email: "admin@example.com",
    role: "admin",
    joinDate: "Nov 2023",
    avatar: "/diverse-group-two.png",
  },
]

const mockPendingCourses = [
  {
    id: "p1",
    title: "Mobile App Design Principles",
    instructor: "Emma Wilson",
    price: "12.5",
    submittedDate: "2 days ago",
  },
  {
    id: "p2",
    title: "Brand Identity Design",
    instructor: "David Kim",
    price: "16.0",
    submittedDate: "1 week ago",
  },
]

const mockPendingPayments = [
  {
    id: "payment_1703123456789",
    course: "Mastering Design Systems in Figma",
    buyer: "John Doe",
    instructor: "Alex Morgan",
    amount: "15.5",
    date: "2 hours ago",
    method: "username",
    piWallet: "GCXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
    status: "pending_approval",
  },
  {
    id: "payment_1703123456790",
    course: "React Development Bootcamp",
    buyer: "Jane Smith",
    instructor: "Mike Chen",
    amount: "22.0",
    date: "5 hours ago",
    method: "qr",
    piWallet: "GCYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY",
    status: "pending_approval",
  },
  {
    id: "payment_1703123456791",
    course: "Advanced UI/UX Design Masterclass",
    buyer: "Bob Johnson",
    instructor: "Sarah Johnson",
    amount: "18.5",
    date: "1 day ago",
    method: "wallet",
    piWallet: "GCZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ",
    status: "pending_approval",
  },
]

const mockTransactions = [
  {
    id: "t1",
    course: "Advanced UI/UX Design Masterclass",
    buyer: "John Doe",
    instructor: "Sarah Johnson",
    amount: "15.5",
    status: "completed",
    date: "2 hours ago",
  },
  {
    id: "t2",
    course: "React Development Bootcamp",
    buyer: "Jane Smith",
    instructor: "Mike Chen",
    amount: "22.0",
    status: "completed",
    date: "5 hours ago",
  },
  {
    id: "t3",
    course: "3D Animation Fundamentals",
    buyer: "Bob Johnson",
    instructor: "Alex Rivera",
    amount: "18.5",
    status: "completed",
    date: "1 day ago",
  },
]
