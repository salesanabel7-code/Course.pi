"use client"

import { useState } from "react"
import { Eye, Edit, Trash2, Clock, Users, Star, Plus } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { MainNav } from "@/components/main-nav"
import { UserNav } from "@/components/user-nav"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function MyCoursesPage() {
  const [activeTab, setActiveTab] = useState("published")

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background">
        <div className="container flex h-16 items-center px-4 sm:px-8">
          <MainNav />
          <div className="ml-auto flex items-center space-x-4">
            <UserNav />
          </div>
        </div>
      </header>

      <main className="flex-1">
        <div className="container px-4 py-6 sm:px-8 md:py-8">
          <div className="mb-8 flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold tracking-tight">My Courses</h1>
              <p className="text-muted-foreground">Manage your created courses and track their performance</p>
            </div>
            <Link href="/create-course">
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Create New Course
              </Button>
            </Link>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList>
              <TabsTrigger value="published">Published ({publishedCourses.length})</TabsTrigger>
              <TabsTrigger value="pending">Pending Review ({pendingCourses.length})</TabsTrigger>
              <TabsTrigger value="drafts">Drafts ({draftCourses.length})</TabsTrigger>
            </TabsList>

            <TabsContent value="published" className="space-y-4">
              {publishedCourses.length === 0 ? (
                <Card>
                  <CardContent className="flex flex-col items-center justify-center py-12">
                    <div className="text-center">
                      <h3 className="text-lg font-medium">No published courses yet</h3>
                      <p className="text-muted-foreground mt-2">Create your first course to start teaching!</p>
                      <Link href="/create-course">
                        <Button className="mt-4">
                          <Plus className="mr-2 h-4 w-4" />
                          Create Course
                        </Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <div className="grid gap-6">
                  {publishedCourses.map((course) => (
                    <Card key={course.id}>
                      <CardContent className="p-6">
                        <div className="flex items-start gap-4">
                          <div className="h-20 w-20 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold text-lg">
                            {course.title.charAt(0)}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <h3 className="text-lg font-semibold">{course.title}</h3>
                                <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{course.description}</p>
                                <div className="flex items-center gap-4 mt-3">
                                  <Badge variant="default">Published</Badge>
                                  <Badge variant="outline">{course.category}</Badge>
                                  <Badge variant="outline">{course.level}</Badge>
                                </div>
                              </div>
                              <div className="text-right">
                                <div className="text-lg font-bold text-green-600">{course.price} π</div>
                                <div className="text-sm text-muted-foreground">{course.duration}</div>
                              </div>
                            </div>
                            <div className="flex items-center justify-between mt-4">
                              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                                <div className="flex items-center gap-1">
                                  <Users className="h-4 w-4" />
                                  <span>{course.enrollments} enrolled</span>
                                </div>
                                <div className="flex items-center gap-1">
                                  <Star className="h-4 w-4 fill-current text-amber-500" />
                                  <span>
                                    {course.rating} ({course.reviews} reviews)
                                  </span>
                                </div>
                                <div>Revenue: {course.revenue} π</div>
                              </div>
                              <div className="flex items-center gap-2">
                                <Button variant="outline" size="sm">
                                  <Eye className="h-4 w-4 mr-1" />
                                  View
                                </Button>
                                <Button variant="outline" size="sm">
                                  <Edit className="h-4 w-4 mr-1" />
                                  Edit
                                </Button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="pending" className="space-y-4">
              {pendingCourses.map((course) => (
                <Card key={course.id}>
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="h-20 w-20 rounded-lg bg-gradient-to-br from-orange-500 to-red-600 flex items-center justify-center text-white font-bold text-lg">
                        {course.title.charAt(0)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h3 className="text-lg font-semibold">{course.title}</h3>
                            <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{course.description}</p>
                            <div className="flex items-center gap-4 mt-3">
                              <Badge variant="outline" className="text-orange-600 border-orange-600">
                                <Clock className="h-3 w-3 mr-1" />
                                Pending Review
                              </Badge>
                              <Badge variant="outline">{course.category}</Badge>
                              <span className="text-sm text-muted-foreground">Submitted {course.submittedDate}</span>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="text-lg font-bold">{course.price} π</div>
                            <div className="text-sm text-muted-foreground">{course.duration}</div>
                          </div>
                        </div>
                        <div className="flex items-center justify-between mt-4">
                          <div className="text-sm text-muted-foreground">
                            <p>Your course is being reviewed by our team. You'll be notified once it's approved.</p>
                          </div>
                          <div className="flex items-center gap-2">
                            <Button variant="outline" size="sm">
                              <Eye className="h-4 w-4 mr-1" />
                              Preview
                            </Button>
                            <Button variant="outline" size="sm">
                              <Edit className="h-4 w-4 mr-1" />
                              Edit
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>

            <TabsContent value="drafts" className="space-y-4">
              {draftCourses.map((course) => (
                <Card key={course.id}>
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="h-20 w-20 rounded-lg bg-gradient-to-br from-gray-400 to-gray-600 flex items-center justify-center text-white font-bold text-lg">
                        {course.title.charAt(0)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h3 className="text-lg font-semibold">{course.title}</h3>
                            <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{course.description}</p>
                            <div className="flex items-center gap-4 mt-3">
                              <Badge variant="secondary">Draft</Badge>
                              <Badge variant="outline">{course.category}</Badge>
                              <span className="text-sm text-muted-foreground">Last edited {course.lastEdited}</span>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="text-lg font-bold">{course.price} π</div>
                            <div className="text-sm text-muted-foreground">{course.duration}</div>
                          </div>
                        </div>
                        <div className="flex items-center justify-between mt-4">
                          <div className="text-sm text-muted-foreground">
                            <p>Complete your course and submit it for review to publish.</p>
                          </div>
                          <div className="flex items-center gap-2">
                            <Button variant="outline" size="sm">
                              <Edit className="h-4 w-4 mr-1" />
                              Continue Editing
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              className="text-destructive hover:text-destructive bg-transparent"
                            >
                              <Trash2 className="h-4 w-4 mr-1" />
                              Delete
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}

// Mock data
const publishedCourses = [
  {
    id: "1",
    title: "Advanced React Patterns",
    description:
      "Master advanced React patterns including render props, higher-order components, and custom hooks for building scalable applications.",
    category: "Web Development",
    level: "Advanced",
    price: "25.0",
    duration: "6h 30m",
    enrollments: 89,
    rating: 4.8,
    reviews: 34,
    revenue: "2,225.0",
  },
]

const pendingCourses = [
  {
    id: "p1",
    title: "Mobile App Design Principles",
    description:
      "Learn the fundamental principles of mobile app design, including user experience, interface design, and platform-specific guidelines.",
    category: "UI Design",
    level: "Intermediate",
    price: "18.5",
    duration: "4h 15m",
    submittedDate: "2 days ago",
  },
]

const draftCourses = [
  {
    id: "d1",
    title: "Introduction to Figma",
    description: "Get started with Figma and learn the basics of interface design and prototyping.",
    category: "Design Tools",
    level: "Beginner",
    price: "12.0",
    duration: "3h 00m",
    lastEdited: "1 week ago",
  },
]
