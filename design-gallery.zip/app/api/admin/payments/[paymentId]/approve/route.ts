import { type NextRequest, NextResponse } from "next/server"

interface PaymentApprovalRequest {
  approved: boolean
  adminId: string
  notes?: string
}

export async function POST(request: NextRequest, { params }: { params: { paymentId: string } }) {
  try {
    const { approved, adminId, notes }: PaymentApprovalRequest = await request.json()
    const { paymentId } = params

    console.log("[v0] Payment approval action:", {
      paymentId,
      approved,
      adminId,
      notes,
      timestamp: new Date().toISOString(),
    })

    // Mock database update
    await new Promise((resolve) => setTimeout(resolve, 1000))

    if (approved) {
      console.log("[v0] Payment approved - unlocking course access:", paymentId)

      const creatorPaymentResponse = await fetch(
        `${process.env.NEXT_PUBLIC_BASE_URL || "http://localhost:3000"}/api/creator-payments`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            paymentId,
            courseId: "course_123", // In real app, get from payment record
            totalAmount: "15.0", // In real app, get from payment record
            creatorId: "creator_123", // In real app, get from course record
          }),
        },
      )

      const creatorPaymentResult = await creatorPaymentResponse.json()
      console.log("[v0] Creator payment processed:", creatorPaymentResult)

      return NextResponse.json({
        success: true,
        message: "Payment approved - course access granted and creator paid",
        paymentId,
        status: "approved",
        courseAccessGranted: true,
        creatorPaymentProcessed: creatorPaymentResult.success,
      })
    } else {
      console.log("[v0] Payment rejected:", paymentId, "Notes:", notes)

      return NextResponse.json({
        success: true,
        message: "Payment rejected",
        paymentId,
        status: "rejected",
        rejectionReason: notes,
      })
    }
  } catch (error) {
    console.error("[v0] Payment approval error:", error)
    return NextResponse.json({ success: false, error: "Failed to process payment approval" }, { status: 500 })
  }
}
