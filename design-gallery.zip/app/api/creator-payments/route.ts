import { type NextRequest, NextResponse } from "next/server"

interface CreatorPayment {
  creatorId: string
  courseId: string
  amount: string
  paymentId: string
  status: "pending" | "processed" | "failed"
}

export async function POST(request: NextRequest) {
  try {
    const { paymentId, courseId, totalAmount, creatorId } = await request.json()

    const platformFeeRate = 0.15
    const creatorShare = Number.parseFloat(totalAmount) * (1 - platformFeeRate)
    const platformFee = Number.parseFloat(totalAmount) * platformFeeRate

    console.log("[v0] Processing creator payment:", {
      paymentId,
      courseId,
      creatorId,
      totalAmount,
      creatorShare,
      platformFee,
      timestamp: new Date().toISOString(),
    })

    // Mock creator payment processing
    await new Promise((resolve) => setTimeout(resolve, 1000))

    const creatorPayment: CreatorPayment = {
      creatorId,
      courseId,
      amount: creatorShare.toFixed(2),
      paymentId,
      status: "processed",
    }

    // In real implementation:
    // 1. Transfer Pi to creator's wallet
    // 2. Update creator earnings in database
    // 3. Send payment notification to creator
    // 4. Update platform revenue records
    // 5. Generate payment receipt

    return NextResponse.json({
      success: true,
      creatorPayment,
      platformFee: platformFee.toFixed(2),
      message: "Creator payment processed successfully",
    })
  } catch (error) {
    console.error("[v0] Creator payment error:", error)
    return NextResponse.json({ success: false, error: "Creator payment processing failed" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const creatorId = searchParams.get("creatorId")

  try {
    // Mock creator earnings data
    const earnings = {
      totalEarnings: "1,250.50",
      pendingPayments: "85.25",
      thisMonth: "320.75",
      coursesSold: 47,
      recentPayments: [
        {
          id: "pay_001",
          courseTitle: "Advanced React Development",
          amount: "12.75",
          date: "2024-01-15",
          status: "processed",
        },
        {
          id: "pay_002",
          courseTitle: "Node.js Masterclass",
          amount: "21.25",
          date: "2024-01-14",
          status: "processed",
        },
        {
          id: "pay_003",
          courseTitle: "TypeScript Fundamentals",
          amount: "8.50",
          date: "2024-01-13",
          status: "pending",
        },
      ],
    }

    return NextResponse.json({ success: true, earnings })
  } catch (error) {
    console.error("[v0] Creator earnings fetch error:", error)
    return NextResponse.json({ success: false, error: "Failed to fetch creator earnings" }, { status: 500 })
  }
}
