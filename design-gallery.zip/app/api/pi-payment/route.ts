import { type NextRequest, NextResponse } from "next/server"

interface PaymentRequest {
  courseId: string
  userId: string
  amount: string
  method: "username" | "qr" | "wallet"
  paymentDetails: {
    piUsername?: string
    walletAddress?: string
    qrCode?: boolean
  }
}

export async function POST(request: NextRequest) {
  try {
    const { courseId, userId, amount, method, paymentDetails }: PaymentRequest = await request.json()

    console.log("[v0] Processing Pi payment:", {
      courseId,
      userId,
      amount,
      method,
      paymentDetails,
      timestamp: new Date().toISOString(),
    })

    // Validate payment method and details
    if (method === "username" && !paymentDetails.piUsername) {
      return NextResponse.json({ success: false, error: "Pi username is required" }, { status: 400 })
    }

    if (method === "wallet" && !paymentDetails.walletAddress) {
      return NextResponse.json({ success: false, error: "Wallet address is required" }, { status: 400 })
    }

    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    const paymentRecord = {
      id: `payment_${Date.now()}`,
      courseId,
      userId,
      amount,
      method,
      paymentDetails,
      status: "pending_approval",
      createdAt: new Date().toISOString(),
      piWalletAddress:
        method === "wallet" ? paymentDetails.walletAddress : `GC${method.toUpperCase()}${"X".repeat(50)}`,
    }

    // In a real implementation, you would:
    // 1. Verify the Pi Network transaction based on method
    // 2. For username: Send payment request via Pi Network API
    // 3. For QR: Generate and validate QR code payment
    // 4. For wallet: Verify wallet address and initiate transfer
    // 5. Store payment record in database with "pending_approval" status
    // 6. Notify admin for approval
    // 7. Send confirmation to user about pending status

    const responseMessage = {
      username: "Payment request sent to Pi Network user",
      qr: "QR code payment initiated",
      wallet: "Wallet payment details recorded",
    }

    return NextResponse.json({
      success: true,
      paymentId: paymentRecord.id,
      status: "pending_approval",
      message: responseMessage[method],
      estimatedApprovalTime: "24 hours",
      paymentMethod: method,
      nextSteps: getNextSteps(method),
    })
  } catch (error) {
    console.error("[v0] Pi payment error:", error)
    return NextResponse.json({ success: false, error: "Payment processing failed" }, { status: 500 })
  }
}

function getNextSteps(method: string): string[] {
  switch (method) {
    case "username":
      return [
        "The recipient will receive a payment request in their Pi Network app",
        "They need to approve the payment request",
        "Once approved, admin will verify and grant course access",
        "You'll receive email confirmation when access is granted",
      ]
    case "qr":
      return [
        "Complete the payment using your Pi Network app",
        "Scan the QR code to confirm the transaction",
        "Admin will verify the blockchain transaction",
        "Course access will be granted upon verification",
      ]
    case "wallet":
      return [
        "Complete the wallet transfer using your Pi Network wallet",
        "Send the exact amount to the provided wallet address",
        "Include the course ID in the transaction memo",
        "Admin will verify the transaction and grant access",
      ]
    default:
      return ["Payment is being processed", "You'll receive updates via email"]
  }
}
