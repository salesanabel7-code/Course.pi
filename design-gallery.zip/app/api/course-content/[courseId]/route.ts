import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest, { params }: { params: { courseId: string } }) {
  try {
    const { courseId } = params
    const userId = request.headers.get("x-user-id") || "user_123"

    // Check if user has access to this course
    const accessResponse = await fetch(`${request.nextUrl.origin}/api/course-access/${courseId}`, {
      headers: {
        "x-user-id": userId,
      },
    })

    const accessData = await accessResponse.json()

    if (!accessData.success || !accessData.hasAccess) {
      return NextResponse.json(
        {
          success: false,
          error: "Access denied",
          message: "You need to purchase this course to access the content",
          hasAccess: false,
        },
        { status: 403 },
      )
    }

    // Return full course content for authorized users
    const fullCourseContent = {
      id: courseId,
      title: "Mastering Design Systems in Figma",
      description: "Complete course content with all lessons and materials",
      modules: [
        {
          id: "module_1",
          title: "Introduction to Design Systems",
          lessons: [
            {
              id: "lesson_1_1",
              title: "What is a Design System?",
              duration: "10:25",
              videoUrl: "/videos/lesson_1_1.mp4",
              transcript: "Welcome to the first lesson on design systems...",
              resources: [
                { name: "Design System Checklist", url: "/resources/checklist.pdf" },
                { name: "Figma Template", url: "/resources/template.fig" },
              ],
            },
            {
              id: "lesson_1_2",
              title: "Benefits of Using Design Systems",
              duration: "12:40",
              videoUrl: "/videos/lesson_1_2.mp4",
              transcript: "In this lesson, we'll explore the key benefits...",
              resources: [{ name: "Case Study Examples", url: "/resources/case-studies.pdf" }],
            },
          ],
        },
        {
          id: "module_2",
          title: "Creating Design Tokens",
          lessons: [
            {
              id: "lesson_2_1",
              title: "Color Tokens and Palettes",
              duration: "14:20",
              videoUrl: "/videos/lesson_2_1.mp4",
              transcript: "Let's dive into creating color tokens...",
              resources: [{ name: "Color Palette Generator", url: "/tools/color-generator" }],
            },
          ],
        },
      ],
      assignments: [
        {
          id: "assignment_1",
          title: "Create Your First Design System",
          description: "Build a basic design system with 5 components",
          dueDate: null,
          submissionFormat: "Figma file",
        },
      ],
      certificates: {
        available: true,
        requirements: "Complete all lessons and assignments",
        templateUrl: "/certificates/template.pdf",
      },
    }

    return NextResponse.json({
      success: true,
      hasAccess: true,
      content: fullCourseContent,
      accessLevel: accessData.accessLevel,
    })
  } catch (error) {
    console.error("[v0] Course content error:", error)
    return NextResponse.json({ success: false, error: "Failed to fetch course content" }, { status: 500 })
  }
}
