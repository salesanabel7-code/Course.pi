import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest, { params }: { params: { courseId: string } }) {
  try {
    const { courseId } = params
    const userId = request.headers.get("x-user-id") || "user_123" // Mock user ID

    console.log("[v0] Checking course access:", { courseId, userId })

    // In a real implementation, you would:
    // 1. Verify user authentication
    // 2. Check if user has purchased the course
    // 3. Verify payment has been approved by admin
    // 4. Return appropriate access level

    // Mock access check - simulate different access levels
    const mockAccessData = {
      hasAccess: courseId === "1" ? Math.random() > 0.5 : false, // Random for demo
      paymentStatus: "approved", // approved, pending, rejected, none
      purchaseDate: "2024-01-15T10:30:00Z",
      expiryDate: null, // null for lifetime access
      accessLevel: "full", // full, preview, none
    }

    return NextResponse.json({
      success: true,
      courseId,
      userId,
      ...mockAccessData,
    })
  } catch (error) {
    console.error("[v0] Course access check error:", error)
    return NextResponse.json({ success: false, error: "Failed to check course access" }, { status: 500 })
  }
}
