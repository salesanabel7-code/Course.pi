import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  try {
    const userId = request.headers.get("x-user-id") || "user_123"

    // In a real implementation, you would fetch from database
    const mockSavedCourses = [
      {
        id: "1",
        title: "Mastering Design Systems in Figma",
        instructor: "Alex Morgan",
        savedAt: "2024-01-15T10:30:00Z",
      },
    ]

    return NextResponse.json({
      success: true,
      savedCourses: mockSavedCourses,
    })
  } catch (error) {
    console.error("[v0] Get saved courses error:", error)
    return NextResponse.json({ success: false, error: "Failed to fetch saved courses" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const { courseId, action } = await request.json() // action: 'save' or 'unsave'
    const userId = request.headers.get("x-user-id") || "user_123"

    console.log("[v0] Save course action:", { courseId, action, userId })

    // In a real implementation, you would:
    // 1. Validate user authentication
    // 2. Add/remove course from user's saved list in database
    // 3. Return updated saved status

    await new Promise((resolve) => setTimeout(resolve, 500)) // Simulate API delay

    return NextResponse.json({
      success: true,
      courseId,
      saved: action === "save",
      message: action === "save" ? "Course saved to your list" : "Course removed from saved list",
    })
  } catch (error) {
    console.error("[v0] Save course error:", error)
    return NextResponse.json({ success: false, error: "Failed to save course" }, { status: 500 })
  }
}
