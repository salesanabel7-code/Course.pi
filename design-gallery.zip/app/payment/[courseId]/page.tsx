"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { toast } from "@/hooks/use-toast"
import { useRouter } from "next/navigation"
import { PiQRGenerator } from "@/components/pi-qr-generator"
import { PiUsernamePayment } from "@/components/pi-username-payment"
import { PiWalletPayment } from "@/components/pi-wallet-payment"

// SVG Icons
const UserIcon = () => (
  <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
    />
  </svg>
)

const QrCodeIcon = () => (
  <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M12 12h4.01M16 20h4M4 12h4m12 0h2M4 4h4m0 0v4m0 0H4m16 0h-4m0 0v4m0 0h4"
    />
  </svg>
)

const WalletIcon = () => (
  <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"
    />
  </svg>
)

const ArrowLeftIcon = () => (
  <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
  </svg>
)

interface Course {
  id: string
  title: string
  price: string
  instructor: string
  instructorWallet: string
}

export default function PaymentOptionsPage({ params }: { params: { courseId: string } }) {
  const [course, setCourse] = useState<Course | null>(null)
  const [selectedMethod, setSelectedMethod] = useState("username")
  const [paymentInitiated, setPaymentInitiated] = useState(false)
  const router = useRouter()

  useEffect(() => {
    // Mock course data - in real app, fetch from API
    setCourse({
      id: params.courseId,
      title: "Advanced React Development",
      price: "15.0",
      instructor: "John Doe",
      instructorWallet: "GCXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
    })
  }, [params.courseId])

  const handlePaymentInitiated = async (paymentDetails: any) => {
    try {
      const response = await fetch("/api/pi-payment", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          courseId: params.courseId,
          amount: course?.price,
          method: selectedMethod,
          paymentDetails,
          userId: "user_123", // In real app, get from auth
        }),
      })

      const result = await response.json()

      if (result.success) {
        setPaymentInitiated(true)
        setTimeout(() => {
          router.push(`/payment/confirmation/${result.paymentId}`)
        }, 2000)
      } else {
        throw new Error(result.error || "Payment failed")
      }
    } catch (error) {
      toast({
        title: "Payment Failed",
        description: "There was an error processing your payment. Please try again.",
        variant: "destructive",
      })
    }
  }

  if (!course) {
    return <div className="flex justify-center items-center min-h-screen">Loading...</div>
  }

  if (paymentInitiated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 to-amber-50 p-4">
        <div className="max-w-2xl mx-auto pt-12">
          <Card>
            <CardContent className="p-8 text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="h-8 w-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                  />
                </svg>
              </div>
              <h2 className="text-2xl font-bold text-green-600 mb-2">Payment Initiated!</h2>
              <p className="text-gray-600 mb-4">Redirecting to confirmation page...</p>
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-orange-600 mx-auto"></div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-amber-50 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <Button variant="ghost" onClick={() => router.back()} className="mb-4">
            <ArrowLeftIcon />
            <span className="ml-2">Back to Course</span>
          </Button>

          <div className="text-center">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Complete Your Purchase</h1>
            <p className="text-gray-600">Choose your preferred Pi payment method</p>
          </div>
        </div>

        {/* Course Info */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="font-semibold text-lg">{course.title}</h3>
                <p className="text-gray-600">by {course.instructor}</p>
              </div>
              <Badge variant="outline" className="text-orange-600 border-orange-600 text-lg px-3 py-1">
                <span className="mr-1">π</span>
                {course.price} Pi
              </Badge>
            </div>
          </CardContent>
        </Card>

        {/* Payment Options */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <span className="text-orange-600">π</span>
              Pi Network Payment Options
            </CardTitle>
            <CardDescription>Select your preferred method to pay with Pi cryptocurrency</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs value={selectedMethod} onValueChange={setSelectedMethod}>
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="username" className="flex items-center gap-2">
                  <UserIcon />
                  Username
                </TabsTrigger>
                <TabsTrigger value="qr" className="flex items-center gap-2">
                  <QrCodeIcon />
                  QR Code
                </TabsTrigger>
                <TabsTrigger value="wallet" className="flex items-center gap-2">
                  <WalletIcon />
                  Wallet
                </TabsTrigger>
              </TabsList>

              <TabsContent value="username" className="mt-6">
                <PiUsernamePayment
                  amount={course.price}
                  courseId={course.id}
                  courseTitle={course.title}
                  onPaymentInitiated={(username) => handlePaymentInitiated({ piUsername: username })}
                />
              </TabsContent>

              <TabsContent value="qr" className="mt-6">
                <div className="text-center space-y-4">
                  <PiQRGenerator
                    amount={course.price}
                    courseId={course.id}
                    recipientWallet={course.instructorWallet}
                    memo={`Course: ${course.title}`}
                  />
                  <Button
                    onClick={() => handlePaymentInitiated({ qrCode: true })}
                    className="bg-orange-600 hover:bg-orange-700"
                  >
                    <span className="mr-2">π</span>
                    Confirm QR Payment
                  </Button>
                </div>
              </TabsContent>

              <TabsContent value="wallet" className="mt-6">
                <PiWalletPayment
                  amount={course.price}
                  courseId={course.id}
                  courseTitle={course.title}
                  recipientWallet={course.instructorWallet}
                  onPaymentInitiated={(walletAddress) => handlePaymentInitiated({ walletAddress })}
                />
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* Security Notice */}
        <div className="mt-6 text-center text-sm text-gray-500">
          <p>🔒 Secure payment powered by Pi Network blockchain</p>
          <p>Your payment will be reviewed and approved within 24 hours</p>
        </div>
      </div>
    </div>
  )
}
