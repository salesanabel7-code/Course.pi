"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { useRouter } from "next/navigation"

const CheckCircleIcon = () => (
  <svg className="h-16 w-16 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
    />
  </svg>
)

const ClockIcon = () => (
  <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
    />
  </svg>
)

const UserIcon = () => (
  <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
    />
  </svg>
)

const QrCodeIcon = () => (
  <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M12 12h4.01M16 20h4M4 12h4m12 0h2M4 4h4m0 0v4m0 0H4m16 0h-4m0 0v4m0 0h4"
    />
  </svg>
)

const WalletIcon = () => (
  <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"
    />
  </svg>
)

interface PaymentDetails {
  id: string
  courseTitle: string
  amount: string
  status: string
  method: string
  createdAt: string
  nextSteps: string[]
}

const methodIcons = {
  username: UserIcon,
  qr: QrCodeIcon,
  wallet: WalletIcon,
}

const methodLabels = {
  username: "Pi Username",
  qr: "QR Code",
  wallet: "Wallet Transfer",
}

export default function PaymentConfirmationPage({ params }: { params: { paymentId: string } }) {
  const [payment, setPayment] = useState<PaymentDetails | null>(null)
  const router = useRouter()

  useEffect(() => {
    // Mock payment data - in real app, fetch from API
    setPayment({
      id: params.paymentId,
      courseTitle: "Advanced React Development",
      amount: "15.0",
      status: "pending_approval",
      method: "username", // This would come from the actual payment record
      createdAt: new Date().toISOString(),
      nextSteps: [
        "The recipient will receive a payment request in their Pi Network app",
        "They need to approve the payment request",
        "Once approved, admin will verify and grant course access",
        "You'll receive email confirmation when access is granted",
      ],
    })
  }, [params.paymentId])

  if (!payment) {
    return <div className="flex justify-center items-center min-h-screen">Loading...</div>
  }

  const MethodIcon = methodIcons[payment.method as keyof typeof methodIcons] || UserIcon

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-amber-50 p-4">
      <div className="max-w-2xl mx-auto pt-12">
        <Card>
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              <CheckCircleIcon />
            </div>
            <CardTitle className="text-2xl">Payment Submitted Successfully!</CardTitle>
            <CardDescription>Your Pi payment has been submitted and is pending admin approval</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="bg-orange-50 p-4 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <ClockIcon />
                <span className="font-semibold">Pending Approval</span>
              </div>
              <p className="text-sm text-gray-600">
                Your payment is being reviewed by our admin team. You'll receive access to the course once approved
                (typically within 24 hours).
              </p>
            </div>

            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-600">Payment ID:</span>
                <span className="font-mono text-sm">{payment.id}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Course:</span>
                <span className="font-semibold">{payment.courseTitle}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Amount:</span>
                <Badge variant="outline" className="text-orange-600 border-orange-600">
                  <span className="mr-1">π</span>
                  {payment.amount} Pi
                </Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Payment Method:</span>
                <div className="flex items-center gap-2">
                  <MethodIcon />
                  <span>{methodLabels[payment.method as keyof typeof methodLabels]}</span>
                </div>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Status:</span>
                <Badge variant="secondary">Pending Approval</Badge>
              </div>
            </div>

            {/* Next Steps */}
            <div className="bg-blue-50 p-4 rounded-lg">
              <h4 className="font-semibold mb-3 text-blue-900">What happens next?</h4>
              <ol className="list-decimal list-inside space-y-2 text-sm text-blue-800">
                {payment.nextSteps.map((step, index) => (
                  <li key={index}>{step}</li>
                ))}
              </ol>
            </div>

            <div className="pt-6 space-y-3">
              <Button onClick={() => router.push("/my-courses")} className="w-full">
                View My Courses
              </Button>
              <Button variant="outline" onClick={() => router.push("/")} className="w-full">
                Continue Browsing
              </Button>
            </div>

            {/* Support Contact */}
            <div className="text-center text-sm text-gray-500 pt-4 border-t">
              <p>Need help? Contact our support team</p>
              <p className="text-orange-600">support@courseplatform.com</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
