"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { MainNav } from "@/components/main-nav"
import { UserNav } from "@/components/user-nav"
import { toast } from "@/hooks/use-toast"
import { Separator } from "@/components/ui/separator"

const UploadIcon = () => (
  <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
    />
  </svg>
)

const PlusIcon = () => (
  <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
  </svg>
)

const XIcon = () => (
  <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12m0 0l-12-12m12 12L6 6" />
  </svg>
)

const SaveIcon = () => (
  <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4"
    />
  </svg>
)

const SendIcon = () => (
  <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
  </svg>
)

const UploadLargeIcon = () => (
  <svg className="h-12 w-12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
    />
  </svg>
)

interface CourseModule {
  id: string
  title: string
  description: string
  videoUrl?: string
  duration: string
}

export default function CreateCoursePage() {
  const [courseData, setCourseData] = useState({
    title: "",
    description: "",
    category: "",
    level: "",
    price: "",
    duration: "",
    thumbnail: null as File | null,
  })

  const [modules, setModules] = useState<CourseModule[]>([])
  const [currentModule, setCurrentModule] = useState<Partial<CourseModule>>({})
  const [isSubmitting, setIsSubmitting] = useState(false)

  const addModule = () => {
    if (currentModule.title && currentModule.description) {
      const newModule: CourseModule = {
        id: Date.now().toString(),
        title: currentModule.title,
        description: currentModule.description,
        duration: currentModule.duration || "10 min",
        videoUrl: currentModule.videoUrl,
      }
      setModules([...modules, newModule])
      setCurrentModule({})
    }
  }

  const removeModule = (id: string) => {
    setModules(modules.filter((module) => module.id !== id))
  }

  const handleSubmit = async (isDraft = false) => {
    setIsSubmitting(true)

    try {
      // Simulate course submission
      await new Promise((resolve) => setTimeout(resolve, 2000))

      toast({
        title: isDraft ? "Course Saved as Draft" : "Course Submitted for Review",
        description: isDraft
          ? "Your course has been saved and can be edited later."
          : "Your course has been submitted for admin approval. You'll be notified once it's reviewed.",
      })

      // Reset form
      setCourseData({
        title: "",
        description: "",
        category: "",
        level: "",
        price: "",
        duration: "",
        thumbnail: null,
      })
      setModules([])
    } catch (error) {
      toast({
        title: "Submission Failed",
        description: "There was an error submitting your course. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background">
        <div className="container flex h-16 items-center px-4 sm:px-8">
          <MainNav />
          <div className="ml-auto flex items-center space-x-4">
            <UserNav />
          </div>
        </div>
      </header>

      <main className="flex-1">
        <div className="container px-4 py-6 sm:px-8 md:py-8 max-w-4xl">
          <div className="mb-8">
            <h1 className="text-3xl font-bold tracking-tight">Create New Course</h1>
            <p className="text-muted-foreground">
              Share your knowledge by creating a course. It will be reviewed by our team before publishing.
            </p>
          </div>

          <div className="space-y-8">
            {/* Basic Information */}
            <Card>
              <CardHeader>
                <CardTitle>Basic Information</CardTitle>
                <CardDescription>Provide the essential details about your course</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="title">Course Title *</Label>
                    <Input
                      id="title"
                      placeholder="e.g., Advanced React Development"
                      value={courseData.title}
                      onChange={(e) => setCourseData({ ...courseData, title: e.target.value })}
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="description">Course Description *</Label>
                    <Textarea
                      id="description"
                      placeholder="Describe what students will learn in this course..."
                      rows={4}
                      value={courseData.description}
                      onChange={(e) => setCourseData({ ...courseData, description: e.target.value })}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="grid gap-2">
                      <Label htmlFor="category">Category *</Label>
                      <Select
                        value={courseData.category}
                        onValueChange={(value) => setCourseData({ ...courseData, category: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="ui-design">UI Design</SelectItem>
                          <SelectItem value="ux-design">UX Design</SelectItem>
                          <SelectItem value="web-dev">Web Development</SelectItem>
                          <SelectItem value="graphic-design">Graphic Design</SelectItem>
                          <SelectItem value="3d-animation">3D & Animation</SelectItem>
                          <SelectItem value="design-tools">Design Tools</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="level">Difficulty Level *</Label>
                      <Select
                        value={courseData.level}
                        onValueChange={(value) => setCourseData({ ...courseData, level: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select level" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="beginner">Beginner</SelectItem>
                          <SelectItem value="intermediate">Intermediate</SelectItem>
                          <SelectItem value="advanced">Advanced</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="grid gap-2">
                      <Label htmlFor="price">Price (π) *</Label>
                      <Input
                        id="price"
                        type="number"
                        step="0.1"
                        placeholder="0.0"
                        value={courseData.price}
                        onChange={(e) => setCourseData({ ...courseData, price: e.target.value })}
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="duration">Total Duration</Label>
                      <Input
                        id="duration"
                        placeholder="e.g., 4h 30m"
                        value={courseData.duration}
                        onChange={(e) => setCourseData({ ...courseData, duration: e.target.value })}
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Course Thumbnail */}
            <Card>
              <CardHeader>
                <CardTitle>Course Thumbnail</CardTitle>
                <CardDescription>Upload an attractive thumbnail for your course</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-6 text-center">
                  <UploadLargeIcon />
                  <div className="mt-4">
                    <Button variant="outline">
                      <UploadIcon />
                      Upload Thumbnail
                    </Button>
                    <p className="text-sm text-muted-foreground mt-2">Recommended: 1280x720px, JPG or PNG, max 2MB</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Course Modules */}
            <Card>
              <CardHeader>
                <CardTitle>Course Content</CardTitle>
                <CardDescription>Add modules and lessons to structure your course</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Add Module Form */}
                <div className="border rounded-lg p-4 space-y-4">
                  <h4 className="font-medium">Add New Module</h4>
                  <div className="grid gap-4">
                    <div className="grid gap-2">
                      <Label htmlFor="module-title">Module Title</Label>
                      <Input
                        id="module-title"
                        placeholder="e.g., Introduction to React Hooks"
                        value={currentModule.title || ""}
                        onChange={(e) => setCurrentModule({ ...currentModule, title: e.target.value })}
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="module-description">Module Description</Label>
                      <Textarea
                        id="module-description"
                        placeholder="Describe what this module covers..."
                        value={currentModule.description || ""}
                        onChange={(e) => setCurrentModule({ ...currentModule, description: e.target.value })}
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="grid gap-2">
                        <Label htmlFor="module-duration">Duration</Label>
                        <Input
                          id="module-duration"
                          placeholder="e.g., 15 min"
                          value={currentModule.duration || ""}
                          onChange={(e) => setCurrentModule({ ...currentModule, duration: e.target.value })}
                        />
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="video-url">Video URL (optional)</Label>
                        <Input
                          id="video-url"
                          placeholder="https://..."
                          value={currentModule.videoUrl || ""}
                          onChange={(e) => setCurrentModule({ ...currentModule, videoUrl: e.target.value })}
                        />
                      </div>
                    </div>
                    <Button onClick={addModule} className="w-fit">
                      <PlusIcon />
                      Add Module
                    </Button>
                  </div>
                </div>

                {/* Module List */}
                {modules.length > 0 && (
                  <div className="space-y-4">
                    <h4 className="font-medium">Course Modules ({modules.length})</h4>
                    {modules.map((module, index) => (
                      <div key={module.id} className="border rounded-lg p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <Badge variant="outline">Module {index + 1}</Badge>
                              <span className="text-sm text-muted-foreground">{module.duration}</span>
                            </div>
                            <h5 className="font-medium">{module.title}</h5>
                            <p className="text-sm text-muted-foreground mt-1">{module.description}</p>
                            {module.videoUrl && <p className="text-xs text-blue-600 mt-2">Video: {module.videoUrl}</p>}
                          </div>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => removeModule(module.id)}
                            className="text-destructive hover:text-destructive"
                          >
                            <XIcon />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Submission */}
            <Card>
              <CardHeader>
                <CardTitle>Submit Course</CardTitle>
                <CardDescription>
                  Save as draft to continue editing later, or submit for review to publish your course
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex gap-4">
                  <Button
                    variant="outline"
                    onClick={() => handleSubmit(true)}
                    disabled={isSubmitting || !courseData.title}
                  >
                    <SaveIcon />
                    Save as Draft
                  </Button>
                  <Button
                    onClick={() => handleSubmit(false)}
                    disabled={
                      isSubmitting ||
                      !courseData.title ||
                      !courseData.description ||
                      !courseData.category ||
                      !courseData.level ||
                      !courseData.price ||
                      modules.length === 0
                    }
                  >
                    <SendIcon />
                    {isSubmitting ? "Submitting..." : "Submit for Review"}
                  </Button>
                </div>
                <Separator className="my-4" />
                <div className="text-sm text-muted-foreground space-y-2">
                  <p>
                    <strong>Review Process:</strong> Your course will be reviewed by our team within 2-3 business days.
                  </p>
                  <p>
                    <strong>Requirements:</strong> All fields marked with * are required, and you must add at least one
                    module.
                  </p>
                  <p>
                    <strong>Payment:</strong> Once approved, students can purchase your course using Pi Network
                    cryptocurrency.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
